package com.example.coingame

import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LaunchPage1 : AppCompatActivity() {
    private lateinit var mediaPlayer: MediaPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_launch_page1)

        // Initialize MediaPlayer with the gamesong.mp3
        mediaPlayer = MediaPlayer.create(this, R.raw.gamesong)
        mediaPlayer.isLooping = true // Loop the music

        val continueButton = findViewById<Button>(R.id.continueButton)
        val newGameButton = findViewById<Button>(R.id.newGameButton)
        val exitButton = findViewById<Button>(R.id.exitButton)
        val settingButton = findViewById<Button>(R.id.settingsButton)

        continueButton.setOnClickListener {
            // Check if there's a saved game state
            val score = intent.getIntExtra("score", 0) // Retrieve the score from intent extras
            if (score > 0) {
                // If the score is greater than 0, resume the game
                val intent = Intent(this, Game::class.java)
                intent.putExtra("score", score) // Pass the score to the Game activity
                startActivity(intent)
            } else {
                // If no game was paused or score is 0, inform the user
                Toast.makeText(this, "No saved game state found.", Toast.LENGTH_SHORT).show()
            }
        }

        newGameButton.setOnClickListener {
            // Start a new game
            startActivity(Intent(this, Game::class.java))
        }

        settingButton.setOnClickListener {
            // Open settings activity
            startActivity(Intent(this, Settings::class.java))
        }

        exitButton.setOnClickListener {
            // Exit the app
            finishAffinity()
        }
    }

    override fun onResume() {
        super.onResume()
        // Start playing the music when LaunchPage1 resumes
        mediaPlayer.start()
    }

    override fun onPause() {
        super.onPause()
        // Pause the music when LaunchPage1 is paused
        mediaPlayer.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        // Release the MediaPlayer resources when LaunchPage1 is destroyed
        mediaPlayer.release()
    }
}
